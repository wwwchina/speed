﻿ASR_demonstration.docx  DEMO 图文测试教程

ASR-INTEGRATION-helloworld   ASR集成指南-集成到helloworld中
ASR-INTEGRATION-TTS-DEMO ASR集成指南-集成到合成DEMO中
IN_FILE-inputstream.md 不使用麦克风输入，使用IN_FILE传入音频数据
bluetooth_SCO.md 蓝牙耳机开启说明

../readme_README_IMPORTANT.txt demo使用的说明文件