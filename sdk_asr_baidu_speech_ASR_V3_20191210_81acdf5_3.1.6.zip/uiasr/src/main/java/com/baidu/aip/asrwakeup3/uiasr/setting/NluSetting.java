package com.baidu.aip.asrwakeup3.uiasr.setting;


import com.baidu.aip.asrwakeup3.uiasr.R;

/**
 * Created by fujiayi on 2017/6/24.
 */

public class NluSetting extends CommonSetting {
    {
        setting =  R.xml.setting_nlu;
        title = "语义理解设置";
    }
}
