package com.baidu.aip.asrwakeup3.uiasr.setting;


import com.baidu.aip.asrwakeup3.uiasr.R;

/**
 * Created by fujiayi on 2017/8/18.
 */

public class AllSetting extends CommonSetting {

    {
        setting = R.xml.setting_all;
        title = "全部识别设置";
    }
}
